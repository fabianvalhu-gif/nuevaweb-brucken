import { Linkedin, Twitter, Instagram, Youtube } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerSections = [
    {
      title: 'Servicios',
      links: [
        'Estrategia de crecimiento',
        'Transformación operacional',
        'Software factory',
        'Expansión internacional',
        'IA y analytics',
        'Transformación digital',
      ],
    },
    {
      title: 'Industrias',
      links: [
        'Technology & SaaS',
        'Financial Services',
        'Retail & Consumer',
        'Healthcare',
        'Manufacturing',
        'Energy & Utilities',
      ],
    },
    {
      title: 'Insights',
      links: [
        'Artículos destacados',
        'Investigación',
        'Whitepapers',
        'Casos de éxito',
        'Webinars',
        'Podcast',
      ],
    },
    {
      title: 'Nosotros',
      links: [
        'Quiénes somos',
        'Liderazgo',
        'Carreras',
        'Ubicaciones',
        'Sostenibilidad',
        'Prensa',
      ],
    },
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Main Footer */}
      <div className="max-w-[1600px] mx-auto px-6 lg:px-12 py-16 lg:py-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-16 mb-16">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-fuchsia-500 rounded"></div>
              <span className="text-xl font-light tracking-tight text-white">
                Brücken<span className="font-medium">Global</span>
              </span>
            </div>
            <p className="text-sm font-light text-gray-400 leading-relaxed">
              Consultoría estratégica y tecnológica para LATAM y mercados globales.
            </p>
          </div>

          {/* Links Sections */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className="text-white text-sm font-normal mb-6 uppercase tracking-wider">
                {section.title}
              </h3>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href="#"
                      className="text-sm text-gray-400 hover:text-white transition-colors font-light"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="pt-8 border-t border-gray-800">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
            {/* Social Links */}
            <div className="flex gap-6">
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-5 h-5" />
              </a>
            </div>

            {/* Legal Links */}
            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">
                © {currentYear} Brücken Global
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Términos de uso
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Privacidad
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Cookies
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Accesibilidad
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

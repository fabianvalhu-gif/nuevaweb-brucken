import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="pt-20 lg:pt-32 pb-16 lg:pb-24 bg-white">
      <div className="max-w-[1600px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7"
          >
            <div className="max-w-3xl">
              <h1 className="text-4xl lg:text-6xl xl:text-7xl font-light text-gray-900 mb-8 leading-tight tracking-tight">
                Transformamos organizaciones con{' '}
                <span className="font-normal text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-fuchsia-600">
                  estrategia e impacto medible
                </span>
              </h1>

              <p className="text-xl lg:text-2xl text-gray-600 mb-10 leading-relaxed font-light">
                Consultoría estratégica y tecnológica para LATAM y mercados globales. Aceleramos crecimiento con metodologías probadas y squads de alto desempeño.
              </p>

              <div className="flex flex-wrap gap-4 items-center">
                <button className="bg-black text-white px-8 py-4 hover:bg-gray-800 transition-colors flex items-center gap-2 group">
                  <span>Conversemos</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <a
                  href="#insights"
                  className="text-gray-900 px-8 py-4 border border-gray-300 hover:border-gray-900 transition-colors"
                >
                  Ver insights
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-5"
          >
            <div className="grid grid-cols-2 gap-8">
              <div className="border-l-2 border-blue-600 pl-6">
                <div className="text-5xl lg:text-6xl font-light text-gray-900 mb-2">
                  150<span className="text-blue-600">+</span>
                </div>
                <div className="text-sm text-gray-600 uppercase tracking-wider">
                  Proyectos estratégicos
                </div>
              </div>

              <div className="border-l-2 border-fuchsia-600 pl-6">
                <div className="text-5xl lg:text-6xl font-light text-gray-900 mb-2">
                  12
                </div>
                <div className="text-sm text-gray-600 uppercase tracking-wider">
                  Países en LATAM
                </div>
              </div>

              <div className="border-l-2 border-blue-600 pl-6">
                <div className="text-5xl lg:text-6xl font-light text-gray-900 mb-2">
                  45<span className="text-blue-600">%</span>
                </div>
                <div className="text-sm text-gray-600 uppercase tracking-wider">
                  Avg. revenue growth
                </div>
              </div>

              <div className="border-l-2 border-fuchsia-600 pl-6">
                <div className="text-5xl lg:text-6xl font-light text-gray-900 mb-2">
                  6M
                </div>
                <div className="text-sm text-gray-600 uppercase tracking-wider">
                  Avg. engagement
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

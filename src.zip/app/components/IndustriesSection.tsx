import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

export function IndustriesSection() {
  const industries = [
    {
      title: 'Technology & SaaS',
      description: 'Aceleramos empresas de software con estrategias de revenue y product-market fit.',
      image: 'https://images.unsplash.com/photo-1765256931300-ceeaed648d21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwaW5ub3ZhdGlvbiUyMGFic3RyYWN0fGVufDF8fHx8MTc2OTM5MTA0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stat: '40%',
      statLabel: 'Avg. ARR growth',
    },
    {
      title: 'Financial Services',
      description: 'Transformación digital y compliance para bancos, fintechs y aseguradoras.',
      image: 'https://images.unsplash.com/photo-1506399558188-acca6f8cbf41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGFuYWx5dGljcyUyMGRhdGF8ZW58MXx8fHwxNzY5MzQ0NTkxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stat: '35%',
      statLabel: 'Cost reduction',
    },
    {
      title: 'Retail & Consumer',
      description: 'Omnicanalidad, customer experience y analytics para retail moderno.',
      image: 'https://images.unsplash.com/photo-1641060272821-df59e2c0b5ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjBhcmNoaXRlY3R1cmV8ZW58MXx8fHwxNzY5NDQwMTYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stat: '50%',
      statLabel: 'Digital sales increase',
    },
  ];

  return (
    <section id="industrias" className="py-16 lg:py-24 bg-gray-50">
      <div className="max-w-[1600px] mx-auto px-6 lg:px-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-light text-gray-900 mb-6 max-w-3xl leading-tight">
            Industrias que <span className="font-normal">transformamos</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl font-light">
            Experiencia profunda en sectores clave con metodologías adaptadas y casos de éxito probados.
          </p>
        </motion.div>

        {/* Industries Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="bg-white overflow-hidden">
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={industry.image}
                    alt={industry.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <h3 className="text-2xl font-light text-gray-900 mb-3">
                    {industry.title}
                  </h3>
                  <p className="text-gray-600 mb-6 font-light leading-relaxed">
                    {industry.description}
                  </p>

                  <div className="flex items-end justify-between border-t border-gray-200 pt-4">
                    <div>
                      <div className="text-3xl font-light text-gray-900">
                        {industry.stat}
                      </div>
                      <div className="text-xs text-gray-500 uppercase tracking-wider">
                        {industry.statLabel}
                      </div>
                    </div>
                    <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-gray-900 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

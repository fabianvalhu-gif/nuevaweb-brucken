import { Header } from '@/app/components/Header';
import { HeroSection } from '@/app/components/HeroSection';
import { FeaturedInsight } from '@/app/components/FeaturedInsight';
import { ServicesSection } from '@/app/components/ServicesSection';
import { IndustriesSection } from '@/app/components/IndustriesSection';
import { ExpertiseSection } from '@/app/components/ExpertiseSection';
import { InsightsSection } from '@/app/components/InsightsSection';
import { AboutSection } from '@/app/components/AboutSection';
import { CTASection } from '@/app/components/CTASection';
import { Footer } from '@/app/components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroSection />
        <FeaturedInsight />
        <ServicesSection />
        <IndustriesSection />
        <ExpertiseSection />
        <InsightsSection />
        <AboutSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
